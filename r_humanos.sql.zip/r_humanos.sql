-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Servidor: localhost
-- Tiempo de generación: 25-05-2023 a las 23:57:44
-- Versión del servidor: 10.4.28-MariaDB
-- Versión de PHP: 8.2.4

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de datos: `r_humanos`
--

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `empleados`
--

CREATE TABLE `empleados` (
  `emp_id` int(11) NOT NULL,
  `emp_name` varchar(50) NOT NULL,
  `emp_apellidos` varchar(50) NOT NULL,
  `emp_telefono` varchar(10) NOT NULL,
  `emp_correo` varchar(50) NOT NULL,
  `emp_direccion` varchar(50) NOT NULL,
  `emp_acc` tinyint(1) NOT NULL,
  `emp_contrasenia` varchar(500) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Volcado de datos para la tabla `empleados`
--

INSERT INTO `empleados` (`emp_id`, `emp_name`, `emp_apellidos`, `emp_telefono`, `emp_correo`, `emp_direccion`, `emp_acc`, `emp_contrasenia`) VALUES
(1, 'Pablo', 'rosales', '3141412', 'asd', 'fsfaf', 0, NULL),
(2, 'juan', 'bosco', '231241', 'bosco', 'sdfsefds', 1, '123'),
(6, 'Diana', 'nose', '1234567890', 'diana', 'asd #34', 1, '123'),
(9, 'asd', 'ad', 'sad', 'sasa', 'zzX', 0, NULL),
(10, 'aaaa', 'aaaa', 'aaaaaa', 'aaaaa', 'aaaaa', 0, NULL),
(11, 'aaaaa', 'aaaaa', 'aaaaa', 'aaaaaaa', 'aaaa', 0, NULL),
(12, 'hgvuyvuu', 'vuygvuyguv', 'uvuyvuvuv', 'uvuvuvh', 'vhgvhvh', 0, NULL),
(13, 'kjbhijbjx', 'jkhbk', 'bnkb', 'jb', 'jbjb', 0, NULL),
(14, 'khjbuygytfv', 'ytfyf', 'ytfyf', 'yftccyv', 'jvjvh', 0, NULL),
(15, 'vvfv', 'rfvcerv', 'frvcfrvc', 'frvcfrcvfr', 'crfcrfc', 0, NULL),
(16, 'frcfrvcfrc', 'rfvcvfrvc', 'rfcvfrcvf', 'rvrfvcf', 'vfrvrfvrfr', 0, NULL),
(17, 'vfrvrfv', 'vfrvfr', 'vfrvfr', 'vrfvrf', 'vrfvrfvr', 0, NULL),
(18, 'vfrvr', 'fvrfvrfvrf', 'vrfvfrvfr', 'frvrvrf', 'vrfvrv', 0, NULL);

--
-- Índices para tablas volcadas
--

--
-- Indices de la tabla `empleados`
--
ALTER TABLE `empleados`
  ADD PRIMARY KEY (`emp_id`);

--
-- AUTO_INCREMENT de las tablas volcadas
--

--
-- AUTO_INCREMENT de la tabla `empleados`
--
ALTER TABLE `empleados`
  MODIFY `emp_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=19;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
